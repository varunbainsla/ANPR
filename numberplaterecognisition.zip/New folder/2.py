import cv2
import os,argparse
import pytesseract
from PIL import Image

img=cv2.imread("car0.jpg")


resize_test_license_plate = cv2.resize(
    img, None, fx = 2, fy = 2, 
    interpolation = cv2.INTER_CUBIC)

gray_img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

grayscale_resize_test_license_plate = cv2.cvtColor(
    resize_test_license_plate, cv2.COLOR_BGR2GRAY)


gaussian_blur_license_plate = cv2.GaussianBlur(
    grayscale_resize_test_license_plate, (5, 5), 0)


custom_config = r'--oem 3 --psm 6'
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'


text=pytesseract.image_to_string(gray_img, config=custom_config)
cv2.imshow('img',grayscale_resize_test_license_plate)
print(text)

new_predicted_result_GWT2180 = pytesseract.image_to_string(gaussian_blur_license_plate, lang ='eng',
config ='--oem 3 -l eng --psm 6 -c tessedit_char_whitelist = ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
filter_new_predicted_result_GWT2180 = "".join(new_predicted_result_GWT2180.split()).replace(":", "").replace("-", "")
print(filter_new_predicted_result_GWT2180)
