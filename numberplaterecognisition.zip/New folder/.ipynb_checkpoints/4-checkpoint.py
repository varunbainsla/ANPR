# Import dependencies
import numpy as np
import matplotlib.pyplot as plt

import cv2 # This is the OpenCV Python library
import pytesseract # This is the TesseractOCR Python library
# Set Tesseract CMD path to the location of tesseract.exe file
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Read car image and convert color to RGB
carplate_img = cv2.imread('car0.jpg')
carplate_img_rgb = cv2.cvtColor(carplate_img, cv2.COLOR_BGR2RGB)
cv2.imshow('img',carplate_img_rgb)

# Import Haar Cascade XML file for Russian car plate numbers
carplate_haar_cascade = cv2.CascadeClassifier('haarcascade_russian_plate_number.xml')


# Setup function to detect car plate
def carplate_detect(image):
    carplate_overlay = image.copy() 
    carplate_rects = carplate_haar_cascade.detectMultiScale(carplate_overlay,scaleFactor=1.1, minNeighbors=3)
    for x,y,w,h in carplate_rects:
        cv2.rectangle(carplate_overlay, (x,y), (x+w,y+h), (255,0,0), 5)
    print(carplate_overlay)

detected_carplate_img = carplate_detect(carplate_img_rgb)
cv2.imshow('detected',detected_carplate_img)






